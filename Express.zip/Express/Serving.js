var express = require("express");
var app = express();
var path = require("path");
app.use(express.json());  // converts frontend data into json format
var mongoose = require("mongoose")

// Tells us about the request hits

// app.use("/" ,function(req,res,next){
//     console.log(req.url);
//     next();
// });

// to know the directory of the file
// console.log(path.join(__dirname ));

// use to access the static files...

app.use(express.static(path.join(__dirname ,"../Frontend"))) // ".. " is use to come out of tyhe directory and "/name_of_directory " is use to add the directory

app.get("/", function(req, res){

    res
        .status(200)
        .sendFile(path.join(__dirname ,"index.html"));  // Here after dirname their should directory name if any . In this not directory name required 

});

app.get("/signup", function(req, res){

    res
        .status(200)
        .sendFile(path.join(__dirname ,"signup.html"));  // Here after dirname their should directory name if any . In this not directory name required 

});

app.get("/success", function(req, res){

    res
        .status(200)
        .sendFile(path.join(__dirname ,"success.html"));  // Here after dirname their should directory name if any . In this not directory name required 

});



//middelware => always top of main route

// app.use("/", function(req ,res ,next){
//     console.log("This is my second output");
//     next();
// });


// app.get("/", function(req,res){
//     console.log("This is my first output")
// });





app.listen(3000 ,function(){
    console.log("we are listening at port 3000")
})

// Backend Mai data enter lane ka code

let user={};
app.get('/user',(req,res)=>{
    let user =new usermodel({
        name: 'Aarush Wasnik',
        email:'def@gmail.com',
        password:'1234',
        confirmpassword:'1234'
    });
   // let data = usermodel.create(user);
   user.save()
   console.log(user);
    res
        .status(200)
        .send(user);
})

// let data = {}
// app.post("/signup",(req,res)=>{
//     var firstname = req.body.firstname;
//     var lastname = req.body.lastname;
//     var email = req.body.email;
//     var password = req.body.password;

//     var data = {
//         "firstname": firstname,
//         "lastname": lastname,
//         "email" : email,
//         "password" : password
//     }
//    data.save()
//    console.log(user);
//     res
//         .status(200)
//         .send(user);
// })

// User se data lena ka post method:

//middlewarefunction for post req


app.post('/user' , (req,res)=>{
    res.status(200);
    console.log(req.body); // terminal/console mai print hota hai 
    user=req.body; // get mai prints karwata hai data of users -> data post se data lena hai phirr get use karna hai 
    res.send({
        Message:"data send successfully",
        user:req.body
    })
});
// update data in user's object. Here object is user 
app.patch('/user',(req,res)=>{
    req.status(200);
    console.log('req.body -> data updated', req.body);
    let datatobeupdated =req.body

    for(key in req.body){
        user[key]=datatobeupdated[key];
    }
    res.send({
        Message: "Data updated successfully",
        
    })
});

// delete the data of user obj
app.delete("/user",(req,res)=>{
    res.status(200);
    user={}
    res.send({
        Message : "Data is delted successfully",
    })
});

//parameters

app.get('/user/:id' ,(req,res)=>{
    console.log(req.params.id);
    res.send("user id recevied successfully");
})

app.get('/user/:Name' ,(req,res)=>{
    console.log(req.params.Name);
    //console.log(req.params);
    res.send("user Name recevied successfully");
})


// mongoose connection

// db password = iDCGun4vx9qoT3FJ


//iDCGun4vx9qoT3FJ
//const db_link = 'mongodb+srv://Ratan:iDCGun4vx9qoT3FJ@cluster0.wzcoulj.mongodb.net/?retryWrites=true&w=majority'
// const db_link ='mongodb://:27017/Turf'
// mongoose.set("strictQuery", false)
// mongoose.connect(db_link)
// .then(function(db){
//     console.log(db);
//    console.log("db is connected"); 
// })
// .catch(function(err){
//     console.log(err);
// })

mongoose
  .connect('mongodb+srv://Ratan:iDCGun4vx9qoT3FJ@cluster0.wzcoulj.mongodb.net/?retryWrites=true&w=majority',{
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("MONGO CONNECTION OPEN!!!");
  })
  .catch((err) => {
    console.log("OH NO MONGO CONNECTION ERROR!!!!");
    console.log(err);
  });

// Crud operation code:
const userschema = mongoose.Schema({
    name:{
        type: String,
        required:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true,
        min: 8 
    },
    confirmpassword :{
        type:String,
        required:true
    }
});

//model
const usermodel = mongoose.model('usermodel',userschema)
